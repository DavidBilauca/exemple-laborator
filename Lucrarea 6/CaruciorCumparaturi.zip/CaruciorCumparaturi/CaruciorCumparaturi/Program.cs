﻿using CaruciorCumparaturi.Domain;
using CaruciorCumparaturi.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions;
using static CaruciorCumparaturi.Domain.Models.Carucior;
using CaruciorCumparaturi.Domain;
using CaruciorCumparaturi.Data;

namespace CaruciorCumparaturi
{
    class Program
    {
        private static string ConnectionString = "";

        //public static List<PretProdus> listaPreturi;

        public static void IncarcareStoc()
        {
            StocLocal.listaProduse = new List<Produs>();
            StocLocal.listaProduse.Add(new Produs(
                "Lapte la 1L",
                20,
                "L100",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            StocLocal.listaProduse.Add(new Produs(
                "Paine",
                100,
                "P100",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            StocLocal.listaProduse.Add(new Produs(
                "Covrigi",
                30,
                "P101",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            StocLocal.listaProduse.Add(new Produs(
                "Iaurt 500ml",
                25,
                "L101",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            StocLocal.listaProduse.Add(new Produs(
                "Cafea",
                20,
                "C100",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
        }

        public static void IncarcarePreturi()
        {
            StocLocal.listaPreturi = new List<PretProdus>();
            StocLocal.listaPreturi.Add(new PretProdus("L100", (decimal)5.87));
            StocLocal.listaPreturi.Add(new PretProdus("P100", (decimal)3.20));
            StocLocal.listaPreturi.Add(new PretProdus("P101", (decimal)2.00));
            StocLocal.listaPreturi.Add(new PretProdus("L101", (decimal)4.20));
            StocLocal.listaPreturi.Add(new PretProdus("C100", (decimal)37.50));
        }

        static void Main(string[] args)
        {
            using ILoggerFactory loggerFactory = ConfigureLoggerFactory();
            ILogger<WorkflowPlataCarucior> logger = loggerFactory.CreateLogger<WorkflowPlataCarucior>();
            
            IncarcareStoc();

            var listaProduse = AdaugareProduse().ToArray();
            ComandaPlataCarucior comanda = new(listaProduse);
            var dbContextBuilder = new DbContextOptionsBuilder<ContextCarucior>()
                                                .UseSqlServer(ConnectionString)
                                                .UseLoggerFactory(loggerFactory);
            ///GradesContext gradesContext = new GradesContext(dbContextBuilder.Options);
            WorkflowPlataCarucior workflow = new WorkflowPlataCarucior();
            CaruciorNevalidat listaProduseNevalidate = new(listaProduse);
            var rezultat= workflow.Executa(comanda, (codProdus)=>true);

            rezultat.Match(
                whenEvenimentPlataCarucior_esec: @eveniment=>
                {
                    Console.WriteLine($"Plata esuata:{@eveniment.Motiv}");
                    return @eveniment;
                },
                whenEvenimentPlataCarucior_succes: @eveniment =>
                {
                    Console.WriteLine($"Plata realizata cu succes");
                    Console.WriteLine(@eveniment.Csv);
                    return @eveniment;
                }
                );

            //Console.WriteLine("------------------------------------------------");
            //foreach(ProdusPlatit in )

        }

        private static ILoggerFactory ConfigureLoggerFactory()
        {
            //ILoggingBuilder builder;

            return LoggerFactory.Create(builder =>
                                builder.AddSimpleConsole(options =>
                                {
                                    options.IncludeScopes = true;
                                    options.SingleLine = true;
                                    options.TimestampFormat = "hh:mm:ss ";
                                })
                                .AddProvider(new Microsoft.Extensions.Logging.Debug.DebugLoggerProvider()));
        }

        private static List<ProdusNevalidat> AdaugareProduse()
        {
            string opt;
            string cant;
            List<ProdusNevalidat> lista=new List<ProdusNevalidat>();
            AfisareStoc();
            do {
                Console.WriteLine("Alegeti un produs (cod):");
                opt=Console.ReadLine();
                //Console.WriteLine()

                var rezultat = from p in StocLocal.listaProduse
                               where p.Cod == opt
                               select p;

                 
                if (rezultat.Count() == 0) Console.WriteLine("Alegeti un produs din stoc\n");
                else
                {
                    Produs rezP = rezultat.First();
                    lista.Add(new ProdusNevalidat(
                        rezP.Denumire,
                        "1",
                        rezP.Cod,
                        rezP.adresa));
                }

            } while (opt.CompareTo("exit")!=0);

            return lista;
        }

     
        public static void AfisareStoc()
        {
            Console.WriteLine("Stoc:\n");
            foreach (Produs p in StocLocal.listaProduse)
            {
                Console.WriteLine(p.ToString()+"\n");
                Console.WriteLine("-------------------------------------------\n");
            }
        }


    }
}
