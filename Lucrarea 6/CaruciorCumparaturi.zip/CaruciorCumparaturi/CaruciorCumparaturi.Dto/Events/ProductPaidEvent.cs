﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaruciorCumparaturi.Dto.Models;

namespace CaruciorCumparaturi.Dto.Events
{
    public record ProductPaidEvent
    {
        public List<ProductDto> Produse { get; init; }
    }
}
