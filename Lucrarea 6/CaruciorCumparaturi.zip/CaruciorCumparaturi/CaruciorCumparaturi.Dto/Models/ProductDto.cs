﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaruciorCumparaturi.Dto.Models
{
    public record ProductDto
    {
        public string Denumire { get; init; }
        public string Cod { get; init; }
        public int Cantitate { get; init; }
        public string Adresa { get; init; }
    }
}
