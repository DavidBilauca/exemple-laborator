﻿using CaruciorCumparaturi.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaruciorCumparaturi.Domain.Models;

namespace CaruciorCumparaturi.Data.Models
{
    public class OrderHeaderDto
    {
        public int OrderHeaderId { get; set; }
        public Adresa Address { get; set; }
        public decimal Total { get; set; }
    }
}
