﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CaruciorCumparaturi.Data.Models;

namespace CaruciorCumparaturi.Data
{
    public class ContextCarucior : DbContext
    {
        public ContextCarucior(DbContextOptions<ContextCarucior> options) : base(options)
        { }
        public DbSet<ProdusDto> Produse { get; set; }

        public DbSet<OrderHeaderDto> OrderHeaders { get; set; }

        public DbSet<OrderLineDto> OrderLines { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProdusDto>().ToTable("Produs").HasKey(c => c.ProductId);
            modelBuilder.Entity<OrderHeaderDto>().ToTable("OrderHeader").HasKey(c => c.OrderHeaderId);
            //modelBuilder.Entity<OrderLineDto>().ToTable("OrderLine").HasKey(c => c.OrderLineId);
        }

    }
}
