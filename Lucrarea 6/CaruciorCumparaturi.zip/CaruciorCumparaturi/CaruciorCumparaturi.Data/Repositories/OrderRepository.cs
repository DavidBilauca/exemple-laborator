﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaruciorCumparaturi.Domain;
using CaruciorCumparaturi.Domain.Models;
using CaruciorCumparaturi.Domain.Repositories;
using LanguageExt;

namespace CaruciorCumparaturi.Data.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        public TryAsync<List<string>> TryGetExistingOrderHeaders(IEnumerable<string> orderHeadersToCheck)
        {
            throw new NotImplementedException();
        }

        public TryAsync<List<string>> TryGetExistingOrderLines(IEnumerable<string> orderLinesToCheck)
        {
            throw new NotImplementedException();
        }
        
    }
}
