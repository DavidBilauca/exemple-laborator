﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using LanguageExt;
using static LanguageExt.Prelude;
using CaruciorCumparaturi.Domain.Models;
using CaruciorCumparaturi.Domain.Repositories;
using static CaruciorCumparaturi.Domain.Models.Carucior;
using CaruciorCumparaturi.Data.Models;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace CaruciorCumparaturi.Data.Repositories
{
    public class ProdusRepository : IProduseRepository
    {
        private readonly ContextCarucior dbContext;
        public ProdusRepository(ContextCarucior dbContext)
        {
            this.dbContext= dbContext;
        }
        /*
        public TryAsync<List<ProdusPlatit>> TryGetExistingProducts() => async () => (await (
                          from p in dbContext.Produse
                          join o in dbContext.OrderLines on p.ProductId equals o.ProductId
                          select new { p.Code, p.Stock, o.ProductId, o.Price, o.Quantity, o.OrderHeaderId }
                          )
                          .AsNoTracking()
                          .ToListAsync())
                          .Select(result => new ProdusPlatit(
                                                   new ProdusValidat(
                                                       Denumire:result.Code,
                                                       Cantitate:result.Quantity, 
                                                       Cod:new CodProdus(result.ProductId),
                                                       adresa:new Adresa()),
                                                   new decimal((double)result.Price)
                          )
                          .ToList());

        */

        TryAsync<List<ProdusPlatit>> IProduseRepository.TryGetExistingProducts()
        {
            throw new NotImplementedException();
        }

        TryAsync<Unit> IProduseRepository.TrySaveProductsAsync(CaruciorPlatit carucior)
        {
            throw new NotImplementedException();
        }
    }
}
