﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using CaruciorCumparaturi.Domain.Models;

namespace CaruciorCumparaturi.Api.Models
{
    public class InputProdus
    {
        [Required]
        [RegularExpression(Produs.Pattern)]
        public string Cod { get; set; }

        [Required]
        public int Cantitate { get; set; }

        [Required]
        public Adresa adresa { get; set; }

        [Required]
        public string Denumire { get; set; }

    }
}
