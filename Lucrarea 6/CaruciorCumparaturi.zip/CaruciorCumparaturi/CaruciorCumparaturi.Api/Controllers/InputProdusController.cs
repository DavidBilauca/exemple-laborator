﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CaruciorCumparaturi.Domain.Repositories;
using CaruciorCumparaturi.Domain;
using CaruciorCumparaturi.Domain.Models;
using CaruciorCumparaturi.Api.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CaruciorCumparaturi.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InputProdusController : ControllerBase
    {
        private ILogger<InputProdusController> logger;

        public InputProdusController(ILogger<InputProdusController> logger)
        {
            this.logger = logger;
        }

        // GET: api/<InputProdusController>
        [HttpGet]
        public async Task<IActionResult> GetAllProducts([FromServices] IProduseRepository produseRepository) =>
            await produseRepository.TryGetExistingProducts().Match(
                Succ: GetAllProductsHandleSuccess,
                Fail: GetAllProductsHandleError
                );
        private ObjectResult GetAllProductsHandleError(Exception ex)
        {
            logger.LogError(ex,ex.Message);
            return base.StatusCode(StatusCodes.Status500InternalServerError, "UnexpectedError");
        }
        private ObjectResult GetAllProductsHandleSuccess(List<CaruciorCumparaturi.Domain.Models.ProdusPlatit> produse) =>
            Ok(produse.Select(produs => new
            {
                produs.produsValidat,
                produs.Pret
            }));

        // POST api/<InputProdusController>
        [HttpPost]
        public async Task<IActionResult> PublishProducts([FromServices] WorkflowPlataCarucior workflowPlataCarucior, [FromBody] InputProdus[] produse)
        {
            var produseNevalidate = produse.Select(MapInputProdusToProdusNevalidat)
                                          .ToList()
                                          .AsReadOnly();
            ComandaPlataCarucior comanda = new(produseNevalidate);
            var result =  workflowPlataCarucior.Executa(comanda,(CodProdus)=>true);
            return result.Match<IActionResult>(
                whenEvenimentPlataCarucior_esec: evenimentEsuat => StatusCode(StatusCodes.Status500InternalServerError, evenimentEsuat.Motiv),
                whenEvenimentPlataCarucior_succes: evenimentSucces => Ok()
                ); 
        }

        private static ProdusNevalidat MapInputProdusToProdusNevalidat(InputProdus produs) =>
            new ProdusNevalidat(
                Denumire: produs.Denumire,
                Cantitate: produs.Cantitate.ToString(),
                Cod: produs.Cod,
                adresa: produs.adresa);
    }
}
