﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaruciorCumparaturi.Domain.Models
{
    public record ComandaPlataCarucior
    {
        public ComandaPlataCarucior(IReadOnlyCollection<ProdusNevalidat> produseNevalidate)
        {
            ProduseNevalidate = produseNevalidate;
        }

        public IReadOnlyCollection<ProdusNevalidat> ProduseNevalidate { get; }

    }
}
