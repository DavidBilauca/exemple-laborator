﻿using CSharp.Choices;

namespace CaruciorCumparaturi.Domain.Models
{

    [AsChoice]
    public static partial class Carucior
    {

        public interface ICarucior { }

        public record CaruciorGol() : ICarucior;
        public record CaruciorNevalidat : ICarucior
        {
            public IReadOnlyCollection<ProdusNevalidat> ListaProduse;
            public CaruciorNevalidat(IReadOnlyCollection<ProdusNevalidat> listaProduse)
            {
                ListaProduse = listaProduse;
            }
        }
        public record CaruciorInvalidat : ICarucior
        {
            public IReadOnlyCollection<ProdusNevalidat> ListaProduse;

            internal CaruciorInvalidat(IReadOnlyCollection<ProdusNevalidat> listaProduse, string motiv)
            {
                ListaProduse = listaProduse;
            }
        }



        public record CaruciorValidat : ICarucior
        {
            public IReadOnlyCollection<ProdusValidat> ListaProduse;
            internal CaruciorValidat(IReadOnlyCollection<ProdusValidat> listaProduse)
            {
                ListaProduse = listaProduse;
            }

        }
        public record CaruciorPlatit : ICarucior
        {
            internal CaruciorPlatit(IReadOnlyCollection<ProdusPlatit> listaProduse, decimal pretTotal, DateTime dataPlatii)
            {
                ListaProduse = listaProduse;
                PretTotal = pretTotal;
                DataPlatii = dataPlatii;
            }

            public IReadOnlyCollection<ProdusPlatit> ListaProduse;
            public DateTime DataPlatii;
            public decimal PretTotal;
            public string Csv { get; }
        }
    
    
    
    
    
        
    }
}
