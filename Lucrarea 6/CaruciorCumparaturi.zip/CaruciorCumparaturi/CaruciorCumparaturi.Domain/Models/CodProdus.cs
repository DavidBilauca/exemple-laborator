﻿using LanguageExt;
using static LanguageExt.Prelude;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CaruciorCumparaturi.Domain.Models
{
    public record CodProdus
    {
        public static readonly Regex validareCod = new("^[A-Z]{1}[0-9]{3}$");
        public string Valoare { get; }

        public CodProdus(string val)
        {
            if (EsteValid(val))
            {
                Valoare = val;
            }
            else
            {
                throw new Exception("Codul de produs este invalid");
            }
        }
        private static bool EsteValid(string stringValue) => validareCod.IsMatch(stringValue);

        public override string ToString()
        {
            return Valoare;
        }
        public static Option<CodProdus> TryParse(string stringValue)
        {
            if (EsteValid(stringValue))
            {
                return Some<CodProdus>(new(stringValue));
            }
            else
            {
                return None;
            }
        }

    }
}
