﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaruciorCumparaturi.Domain.Models
{
    public record PretProdus
    {
        public string Cod { get; }
        public decimal valoare { get; set; }

        public PretProdus(string cod,decimal valoare)
        {
            Cod = cod;
            valoare = valoare;
        }

    }
}
