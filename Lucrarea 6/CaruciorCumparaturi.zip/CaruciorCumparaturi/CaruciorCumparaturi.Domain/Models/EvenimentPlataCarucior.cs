﻿using CSharp.Choices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaruciorCumparaturi.Domain.Models
{
    [AsChoice]
    public static partial class EvenimentPlataCarucior
    {
        public interface IEvenimentPlataCarucior { }

        public record EvenimentPlataCarucior_succes : IEvenimentPlataCarucior
        {
            public string Csv { get; }
            public DateTime DataPlatii { get; }

            internal EvenimentPlataCarucior_succes(string csv, DateTime dataPlatii)
            {
                Csv = csv;
                DataPlatii = dataPlatii;
            }
        }

        public record EvenimentPlataCarucior_esec : IEvenimentPlataCarucior
        {
            public string Motiv { get; }
            internal EvenimentPlataCarucior_esec(string motiv)
            {
                Motiv = motiv;
            }
        }


    }
}
