﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace CaruciorCumparaturi.Domain.Models
{
    public record Adresa
    {
        public static readonly Regex validareTara = new("^[A-Z]$");
        public static readonly Regex validareLocalitate = new("^[A-Z]$");
        public static readonly Regex validareNr = new("^[0-9]$");
        public static readonly Regex validareStrada = new("^[A-Z]$");

        public string Tara { get; }
        public string Localitate { get; }
        public string Strada { get; }
        public int Numar { get; }

        public Adresa() { }
        public Adresa(string tara, string localitate, string strada, int numar)
        {
            Tara = tara;
            Localitate = Localitate;
            Strada = strada;
            Numar = numar;
        }

        public override string ToString()
        {
            return $"{Tara}, {Localitate}, Str.{Strada}, nr.{Numar} ";
        }

        public static bool ValidareAdresa(ProdusNevalidat produs, out Adresa adresaValida)
        {
            bool esteValid = true;
            if (!validareTara.IsMatch(produs.adresa.Tara)) esteValid = false;
            if (!validareLocalitate.IsMatch(produs.adresa.Localitate)) esteValid = false;
            if (!validareStrada.IsMatch(produs.adresa.Strada)) esteValid = false;
            if (!validareNr.IsMatch(produs.adresa.Numar.ToString())) esteValid = false;
            adresaValida = esteValid ? produs.adresa : null;
            return esteValid;

        }

    }
}
