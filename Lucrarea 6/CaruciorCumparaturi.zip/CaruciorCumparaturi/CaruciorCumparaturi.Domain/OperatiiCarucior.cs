﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaruciorCumparaturi.Domain.Models;
using static CaruciorCumparaturi.Domain.Models.Carucior;

namespace CaruciorCumparaturi.Domain
{
    public static class OperatiiCarucior
    {

        public static ICarucior ValidareCarucior(Func<string, bool> verificareExistentaProdus, CaruciorNevalidat carucior)
        {
            List<ProdusValidat> caruciorValidat = new();
            bool esteListaValida = true;
            string motivInvalidare=string.Empty;
            foreach (var produsNevalidat in carucior.ListaProduse)
            {
                if (!Produs.TryParse_cod(produsNevalidat.Cod,out string codValid))
                {
                    motivInvalidare = $"Cod invalid ({produsNevalidat.Cod}). Formatul valid este 1[A-Z]3[0-9]";
                    esteListaValida = false;
                    break;
                }
                if (!Produs.TryParse_numeric(produsNevalidat.Cantitate,out int cantitateValida))
                {
                    motivInvalidare = $"Cantitate invalida ({produsNevalidat.Cantitate}).Cantitatea se introduce strict in format numeric (baza 10)";
                    esteListaValida = false;
                    break;
                }
                if (!Produs.VerificareStoc(produsNevalidat.Cod, (int)cantitateValida, StocLocal.listaProduse, out int cantitateDisponibila))
                {
                    motivInvalidare = $"Produsul nu exista in stoc sau nu se afla in cantitate suficienta ({produsNevalidat.Cod} , {produsNevalidat.Cantitate})";
                    esteListaValida = false;
                    break;
                }
                if (!Adresa.ValidareAdresa(produsNevalidat, out Adresa adresaValida))
                {
                    motivInvalidare = $"Produsul nu are o adresa valida ({produsNevalidat.adresa})";
                    esteListaValida = false;
                    break;
                }
                ProdusValidat produsValidat = new(produsNevalidat.Denumire,cantitateValida,new CodProdus(codValid),adresaValida);
                caruciorValidat.Add(produsValidat);
            }
            if (esteListaValida)
            {
                return new CaruciorValidat(caruciorValidat);
            }
            else
            {
                return new CaruciorInvalidat(carucior.ListaProduse, motivInvalidare);
            }
            
        }




        public static decimal CalcularePretProdus(ProdusValidat produs)
        {
            var listaPret = StocLocal.listaPreturi;
            var rezultat = from pr in listaPret
                           where produs.Cod.ToString() == pr.Cod
                           select pr;
            return rezultat.First().valoare * produs.Cantitate;

        }
        public static ICarucior CalcularePretCarucior(ICarucior carucior) => carucior.Match(
            whenCaruciorGol: caruciorGol => caruciorGol,
            whenCaruciorNevalidat: caruciorNevalid => caruciorNevalid,
            whenCaruciorInvalidat: caruciorInvalid => caruciorInvalid,
            whenCaruciorValidat: caruciorValid => caruciorValid,
            whenCaruciorPlatit: caruciorPlatit =>
            {
                decimal total = 0;
                var caruciorPl = caruciorPlatit.ListaProduse.Select(produsPlatit =>
                        new ProdusPlatit(produsPlatit.produsValidat, CalcularePretProdus(produsPlatit.produsValidat)));
                foreach (ProdusPlatit ppl in caruciorPl)
                {
                    total += ppl.Pret;
                }
                return new CaruciorPlatit(caruciorPl.ToList().AsReadOnly(),total,DateTime.Now);
            });

        
        

    }
}
