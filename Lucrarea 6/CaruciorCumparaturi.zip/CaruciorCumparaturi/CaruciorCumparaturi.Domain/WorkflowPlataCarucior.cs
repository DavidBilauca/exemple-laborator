﻿using System;
using CaruciorCumparaturi.Domain;
using CaruciorCumparaturi.Domain.Models;
using static CaruciorCumparaturi.Domain.OperatiiCarucior;
using static CaruciorCumparaturi.Domain.Models.Carucior;
using static CaruciorCumparaturi.Domain.Models.EvenimentPlataCarucior;

namespace CaruciorCumparaturi.Domain
{
    public class WorkflowPlataCarucior
    {
        //parametrul string din Func<string,...> va contine codul produsului
        public IEvenimentPlataCarucior Executa( ComandaPlataCarucior comanda, Func<string, bool> verificaExistentaProdus)
        {
            CaruciorNevalidat caruciorNevalidat = new CaruciorNevalidat(comanda.ProduseNevalidate);
            ICarucior carucior = ValidareCarucior(verificaExistentaProdus, caruciorNevalidat);
            carucior = CalcularePretCarucior(carucior);
            //carucior = PlatesteCarucior(carucior);

            return carucior.Match(
                whenCaruciorGol: caruciorGol=> new EvenimentPlataCarucior_esec("Caruciorul a ramas in starea: Gol."),
                whenCaruciorNevalidat: caruciorNevalidat=> new EvenimentPlataCarucior_esec("Caruciorul a ramas in starea: Nevalidat.") as IEvenimentPlataCarucior,
                whenCaruciorInvalidat: caruciorInvalidat=> new EvenimentPlataCarucior_esec("Caruciorul a ramas in starea: Invalid."),
                whenCaruciorValidat: caruciorValidat=> new EvenimentPlataCarucior_esec("caruciorul a ramas in starea: Validat."),
                whenCaruciorPlatit: caruciorPlatit=> new EvenimentPlataCarucior_succes(caruciorPlatit.Csv,caruciorPlatit.DataPlatii)
                );
        }
    }
}
