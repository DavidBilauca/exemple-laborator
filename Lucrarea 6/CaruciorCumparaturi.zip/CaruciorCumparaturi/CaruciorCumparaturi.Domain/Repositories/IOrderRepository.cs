﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LanguageExt;

namespace CaruciorCumparaturi.Domain.Repositories
{
    public interface IOrderRepository
    {
        TryAsync<List<string>> TryGetExistingOrderHeaders(IEnumerable<string> orderHeadersToCheck);
        TryAsync<List<string>> TryGetExistingOrderLines(IEnumerable<string> orderLinesToCheck);
    }
}
