﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LanguageExt;
using CaruciorCumparaturi.Domain.Models;
using static CaruciorCumparaturi.Domain.Models.Carucior;

namespace CaruciorCumparaturi.Domain.Repositories
{
    public interface IProduseRepository
    {
        TryAsync<List<ProdusPlatit>> TryGetExistingProducts();
        TryAsync<Unit> TrySaveProductsAsync(CaruciorPlatit carucior); 
    }
}
