﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaruciorCumparaturi.Domain.Models;

namespace CaruciorCumparaturi.Domain
{
    public static class StocLocal
    {
        public static List<Produs> listaProduse;
        public static List<PretProdus> listaPreturi;

    }
}
