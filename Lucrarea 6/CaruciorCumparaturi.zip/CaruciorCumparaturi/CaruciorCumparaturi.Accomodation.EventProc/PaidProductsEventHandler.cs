﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaruciorCumparaturi.Domain;
using CaruciorCumparaturi.Events;
using CaruciorCumparaturi.Events.Models;
using CaruciorCumparaturi.Dto.Events;

namespace CaruciorCumparaturi.Accomodation.EventProc
{
    internal class PaidProductEventHandler : AbstractEventHandler<ProductPaidEvent>
    {
        public override string[] EventTypes => new string[] { typeof(ProductPaidEvent).Name };

        protected override Task<EventProcessingResult> OnHandleAsync(ProductPaidEvent eventData)
        {
            Console.WriteLine(eventData.ToString());
            return Task.FromResult(EventProcessingResult.Completed);
        }
    }
}
