﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace PSSC_L1_carucior_cumparaturi.Domain
{
    public record Produs
    {
        public static readonly Regex validareCod = new("^[A-Z]{1}[0-9]{3}$");

        public int Cantitate { get; set; }
        public string Cod { get; }
        public Adresa adresa { get; }

        public string Denumire { get; }

        public Produs(string denumire,int cantitate, string cod, Adresa adresa)
        {
            this.Cantitate = cantitate;
            this.Cod = cod;
            this.adresa = adresa;
            this.Denumire = denumire;
        }
        
        public override string ToString()
        {
            return $"{Denumire}, cantitate:{Cantitate}, cod: {Cod} ,{adresa} ";
        }

        public static bool TryParse_numeric(string valueString,out int number)
        {
            if (decimal.TryParse(valueString, out decimal numericValue))
            {
                number = (int)numericValue;
                return true;
            }
            else
            {
                number = 0;
                return false;
            }
        }
        public static bool TryParse_cod(string cod,out string codValid)
        {
            if (validareCod.IsMatch(cod))
            {
                codValid = cod;
                return true;
            }
            else
            {
                codValid = null;
                return false;
            }
        }

        //se verifica existenta in stoc dar si disponibilitatea cantitatii cerute
        public static bool VerificareStoc(string cod,int cantitate, List<Produs> stoc,out int cantitateDisponibila)
        {
            var rezultat = from p in stoc
                           where p.Cod == cod
                           select p;
            cantitateDisponibila = rezultat.First().Cantitate;
            if (rezultat.Count() == 0) return false;
            if (rezultat.First().Cantitate > cantitate)
                return true;
            else return false;
        }

       


    }
}
