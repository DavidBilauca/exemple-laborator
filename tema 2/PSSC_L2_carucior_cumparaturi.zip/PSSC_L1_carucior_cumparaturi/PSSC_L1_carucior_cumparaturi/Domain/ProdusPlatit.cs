﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSSC_L1_carucior_cumparaturi.Domain
{
    public record ProdusPlatit(ProdusValidat produsValidat,decimal Pret);
}
