﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSSC_L1_carucior_cumparaturi.Domain
{
    public record PretProdus
    {
        public string Cod { get; }
        public decimal valoare { get; set; }

        public PretProdus(string cod,decimal valoare)
        {
            Cod = cod;
            valoare = valoare;
        }

    }
}
