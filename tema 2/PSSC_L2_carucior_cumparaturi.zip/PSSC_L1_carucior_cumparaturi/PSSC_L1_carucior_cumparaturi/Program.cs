﻿using PSSC_L1_carucior_cumparaturi.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using static PSSC_L1_carucior_cumparaturi.Domain.Carucior;
using static PSSC_L1_carucior_cumparaturi.WorkflowPlataCarucior;

namespace PSSC_L1_carucior_cumparaturi
{
    class Program
    {
        public static List<Produs> listaProduseStoc;

        public static List<PretProdus> listaPreturi;

        public static void IncarcareStoc()
        {
            listaProduseStoc = new List<Produs>();
            listaProduseStoc.Add(new Produs(
                "Lapte la 1L",
                20,
                "L100",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            listaProduseStoc.Add(new Produs(
                "Paine",
                100,
                "P100",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            listaProduseStoc.Add(new Produs(
                "Covrigi",
                30,
                "P101",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            listaProduseStoc.Add(new Produs(
                "Iaurt 500ml",
                25,
                "L101",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
            listaProduseStoc.Add(new Produs(
                "Cafea",
                20,
                "C100",
                new Adresa("Romania", "Timisoara", "Calea Aradului", 56)
                ));
        }

        public static void IncarcarePreturi()
        {
            listaPreturi = new List<PretProdus>();
            listaPreturi.Add(new PretProdus("L100", (decimal)5.87));
            listaPreturi.Add(new PretProdus("P100", (decimal)3.20));
            listaPreturi.Add(new PretProdus("P101", (decimal)2.00));
            listaPreturi.Add(new PretProdus("L101", (decimal)4.20));
            listaPreturi.Add(new PretProdus("C100", (decimal)37.50));
        }

        static void Main(string[] args)
        {
            IncarcareStoc();


            var listaProduse = AdaugareProduse().ToArray();
            //
            ComandaPlataCarucior comanda = new(listaProduse);
            //
            WorkflowPlataCarucior workflow = new WorkflowPlataCarucior();
            CaruciorNevalidat listaProduseNevalidate = new(listaProduse);
            var rezultat= workflow.Executa(comanda, (codProdus)=>true);

            rezultat.Match(
                whenEvenimentPlataCarucior_esec: @eveniment=>
                {
                    Console.WriteLine($"Plata esuata:{@eveniment.Motiv}");
                    return @eveniment;
                },
                whenEvenimentPlataCarucior_succes: @eveniment =>
                {
                    Console.WriteLine($"Plata realizata cu succes");
                    Console.WriteLine(@eveniment.Csv);
                    return @eveniment;
                }
                );

        }

        private static List<ProdusNevalidat> AdaugareProduse()
        {
            string opt;
            List<ProdusNevalidat> lista=new List<ProdusNevalidat>();
            AfisareStoc();
            do {
                Console.WriteLine("Alegeti un produs (cod):");
                opt=Console.ReadLine();


                var rezultat = from p in listaProduseStoc
                               where p.Cod == opt
                               select p;

                //rezolva cu exceptie 
                if (rezultat.Count() == 0) Console.WriteLine("Alegeti un produs din stoc\n");
                else
                {
                    Produs rezP = rezultat.First();
                    lista.Add(new ProdusNevalidat(
                        rezP.Denumire,
                        "1",
                        rezP.Cod,
                        rezP.adresa));
                }

            } while (opt.CompareTo("exit")!=0);

            return lista;
        }

     
        public static void AfisareStoc()
        {
            Console.WriteLine("Stoc:\n");
            foreach (Produs p in listaProduseStoc)
            {
                Console.WriteLine(p.ToString()+"\n");
                Console.WriteLine("-------------------------------------------\n");
            }
        }


    }
}
