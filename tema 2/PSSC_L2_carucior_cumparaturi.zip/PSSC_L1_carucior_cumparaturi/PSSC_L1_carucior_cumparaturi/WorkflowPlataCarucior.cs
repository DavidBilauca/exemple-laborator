﻿using System;
using static PSSC_L1_carucior_cumparaturi.Domain.EvenimentPlataCarucior;
using PSSC_L1_carucior_cumparaturi.Domain;
using static PSSC_L1_carucior_cumparaturi.Domain.Carucior;
using static PSSC_L1_carucior_cumparaturi.OperatiiCarucior;

namespace PSSC_L1_carucior_cumparaturi
{
    public class WorkflowPlataCarucior
    {
        //parametrul string din Func<string,...> va contine codul produsului
        public IEvenimentPlataCarucior Executa( ComandaPlataCarucior comanda, Func<string, bool> verificaExistentaProdus)
        {
            CaruciorNevalidat caruciorNevalidat = new CaruciorNevalidat(comanda.ProduseNevalidate);
            ICarucior carucior = ValidareCarucior(verificaExistentaProdus, caruciorNevalidat);
            carucior = CalcularePretCarucior(carucior);
            //carucior = PlatesteCarucior(carucior);

            return carucior.Match(
                whenCaruciorGol: caruciorGol=> new EvenimentPlataCarucior_esec("Caruciorul a ramas in starea: Gol."),
                whenCaruciorNevalidat: caruciorNevalidat=> new EvenimentPlataCarucior_esec("Caruciorul a ramas in starea: Nevalidat.") as IEvenimentPlataCarucior,
                whenCaruciorInvalidat: caruciorInvalidat=> new EvenimentPlataCarucior_esec("Caruciorul a ramas in starea: Invalid."),
                whenCaruciorValidat: caruciorValidat=> new EvenimentPlataCarucior_esec("caruciorul a ramas in starea: Validat."),
                whenCaruciorPlatit: caruciorPlatit=> new EvenimentPlataCarucior_succes(caruciorPlatit.Csv,caruciorPlatit.DataPlatii)
                );
        }
    }
}
